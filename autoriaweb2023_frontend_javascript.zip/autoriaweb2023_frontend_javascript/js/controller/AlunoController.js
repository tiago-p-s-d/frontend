import alunoView from "../view/alunoView.js";
import { API_BASE_URL } from "../config/config.js";

/**
 * Renderiza o formulário de aluno.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde o formulário será renderizado.
 */
function renderizaralunoFormulario(componentePrincipal) {
  componentePrincipal.innerHTML = alunoView.renderizarFormulario();
  document.getElementById("formulario_aluno").addEventListener("submit", cadastraraluno);
}

/**
 * Cadastra uma nova aluno.
 * @param {Event} event - Evento do formulário.
 */
async function cadastraraluno(event) {
  event.preventDefault();
  

  const nome_aluno = document.getElementById("aluno_nome_aluno_formulario").value;
  const nome_casa = document.getElementById("aluno_nome_casa_formulario").value;
  const nome_patrono = document.getElementById("aluno_nome_patrono_formulario").value;
  
  const novaaluno = { nome_aluno: nome_aluno, nome_casa: nome_casa,  nome_patrono: nome_patrono,};

  try {
    await fetch(`${API_BASE_URL}/aluno`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(novaaluno),
    });
    const componentePrincipal = document.querySelector("#conteudo_principal");
    await renderizarListaaluno(componentePrincipal);
  } catch (error) {
    console.error("Erro ao adicionar aluno:", error);
  }
}
/**
 * Renderiza a lista de aluno.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde a lista será renderizada.
 */
async function renderizarListaaluno(componentePrincipal) {
  try {
    const response = await fetch(API_BASE_URL + "/aluno");
    const alunoBD = await response.json(); 

    const aluno = alunoBD.map((row) => {
      return {
        id: row.id,
        nome_aluno: row.nome_aluno,
        nome_casa: row.nome_casa,
        nome_patrono: row.nome_patrono,
        
      };
    });
    componentePrincipal.innerHTML = alunoView.renderizarTabela(aluno);
    inserirEventosExcluir();
    inserirEventosAtualizar();
  } catch (error) {
    console.error("Erro ao buscar aluno:", error);
  }
}

/**
 * Adiciona eventos de clique aos botões de exclusão de aluno.
 * Cada botão, quando clicado, aciona a função de exclusão de aluno correspondente.
 */
function inserirEventosExcluir() {
  const botoesExcluir = document.querySelectorAll(".excluir-btn");
  botoesExcluir.forEach((botao) => {
    botao.addEventListener("click", function () {
      const alunoId = this.getAttribute("aluno-id");
      excluiraluno(alunoId);
    });
  });
}

/**
 * Adiciona eventos de clique aos botões de atualização de aluno.
 * Cada botão, quando clicado, aciona a função de buscar a aluno específica para atualização.
 */
function inserirEventosAtualizar() {
  const botoesAtualizar = document.querySelectorAll(".atualizar-btn");
  botoesAtualizar.forEach((botao) => {
    botao.addEventListener("click", function () {
      const alunoId = this.getAttribute("aluno-atualizar-id");
      buscaraluno(alunoId);
    });
  });
}

/**
 * Exclui uma aluno específica com base no ID.
 * Após a exclusão bem-sucedida, a lista de aluno é atualizada.
 * @param {string} id - ID da aluno a ser excluída.
 */
async function excluiraluno(id) {
  try {
    const response = await fetch(`${API_BASE_URL}/aluno/${id}`, { method: "DELETE" });
    if (!response.ok) throw new Error("Erro ao excluir a aluno");
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListaaluno(componentePrincipal);
  } catch (error) {
    console.error("Erro ao excluir a aluno:", error);
  }
}

/**
 * Busca uma aluno específica para atualização, com base no ID.
 * Após encontrar a aluno, renderiza o formulário de atualização.
 * @param {string} id - ID da aluno a ser buscada.
 */
async function buscaraluno(id) {
  try {
    const response = await fetch(`${API_BASE_URL}/aluno/${id}`);
    const alunoBD = await response.json();
    if (alunoBD.length <= 0) return;

    const aluno = alunoBD.map(row => ({
      id: row.id,
      nome_aluno: row.nome_aluno,
        nome_casa: row.nome_casa,
        nome_patrono: row.nome_patrono,
    }))[0];

    const componentePrincipal = document.querySelector("#conteudo_principal");
    componentePrincipal.innerHTML = alunoView.renderizarFormularioAtualizar(aluno);
    document.getElementById("formulario_aluno_atualizar").addEventListener("submit", atualizaraluno);
  } catch (error) {
    console.error("Erro ao buscar aluno:", error);
  }
}

/**
 * Atualiza uma aluno específica.
 * A função é acionada pelo evento de submit do formulário de atualização.
 * @param {Event} event - O evento de submit do formulário.
 */
async function atualizaraluno(event) {
  event.preventDefault();

  const idValor = document.getElementById("aluno_id_formulario").value;
  
  const nome_aluno = document.getElementById("aluno_nome_formulario").value;

  const nome_casa = document.getElementById("aluno_casa_formulario").value;
  
  const nome_patrono = document.getElementById("aluno_patrono_formulario").value;

  const aluno = {id: idValor, nome_aluno: nome_aluno,nome_casa: nome_casa, nome_patrono:nome_patrono,};

  try {
    const response = await fetch(`${API_BASE_URL}/aluno`, {
      method: "PUT",
      headers: {"Content-Type": "application/json",},
      body: JSON.stringify(aluno),
    });

    if (!response.ok) {
      throw new Error("Falha ao atualizar a aluno");
    }
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListaaluno(componentePrincipal);
  } catch (error) {
    
    console.error("Erro ao atualizar aluno:", error);
  }
}

const alunoController = {
  renderizaralunoFormulario,
  cadastraraluno,
  renderizarListaaluno,
  excluiraluno,
};

export default alunoController;
