import patronoView from "../view/patronoView.js";
import { API_BASE_URL } from "../config/config.js";

/**
 * Renderiza o formulário de patrono.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde o formulário será renderizado.
 */
function renderizarpatronoFormulario(componentePrincipal) {
  componentePrincipal.innerHTML = patronoView.renderizarFormulario();
  document.getElementById("formulario_patrono").addEventListener("submit", cadastrarpatrono);
}

/**
 * Cadastra uma nova patrono.
 * @param {Event} event - Evento do formulário.
 */
async function cadastrarpatrono(event) {
  event.preventDefault();
  const nome_pat = document.getElementById("patrono_nome_pat_formulario").value;
  const desc_pat = document.getElementById("patrono_desc_pat_formulario").value;
  const nome_especie = document.getElementById("patrono_nome_especie_formulario").value;

  
  const novapatrono = { nome_pat: nome_pat, desc_pat: desc_pat, nome_especie:nome_especie};

  try {
    await fetch(`${API_BASE_URL}/patrono`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(novapatrono),
    });
    const componentePrincipal = document.querySelector("#conteudo_principal");
    await renderizarListapatrono(componentePrincipal);
  } catch (error) {
    console.error("Erro ao adicionar patrono:", error);
  }
}
/**
 * Renderiza a lista de patrono.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde a lista será renderizada.
 */
async function renderizarListapatrono(componentePrincipal) {
  try {
    const response = await fetch(API_BASE_URL + "/patrono");
    const patronoBD = await response.json(); 

    const patrono = patronoBD.map((row) => {
      return {
        id: row.id,
        nome_pat: row.nome_pat,
        desc_pat: row.desc_pat,
        nome_especie: row.nome_especie,
      };
    });
    componentePrincipal.innerHTML = patronoView.renderizarTabela(patrono);
    inserirEventosExcluir();
    inserirEventosAtualizar();
  } catch (error) {
    console.error("Erro ao buscar patrono:", error);
  }
}

/**
 * Adiciona eventos de clique aos botões de exclusão de patrono.
 * Cada botão, quando clicado, aciona a função de exclusão de patrono correspondente.
 */
function inserirEventosExcluir() {
  const botoesExcluir = document.querySelectorAll(".excluir-btn");
  botoesExcluir.forEach((botao) => {
    botao.addEventListener("click", function () {
      const patronoId = this.getAttribute("patrono-id");
      excluirpatrono(patronoId);
    });
  });
}

/**
 * Adiciona eventos de clique aos botões de atualização de patrono.
 * Cada botão, quando clicado, aciona a função de buscar a patrono específica para atualização.
 */
function inserirEventosAtualizar() {
  const botoesAtualizar = document.querySelectorAll(".atualizar-btn");
  botoesAtualizar.forEach((botao) => {
    botao.addEventListener("click", function () {
      const patronoId = this.getAttribute("patrono-atualizar-id");
      buscarpatrono(patronoId);
    });
  });
}

/**
 * Exclui uma patrono específica com base no ID.
 * Após a exclusão bem-sucedida, a lista de patrono é atualizada.
 * @param {string} id - ID da patrono a ser excluída.
 */
async function excluirpatrono(id) {
  try {
    const response = await fetch(`${API_BASE_URL}/patrono/${id}`, { method: "DELETE" });
    if (!response.ok) throw new Error("Erro ao excluir a patrono");
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListapatrono(componentePrincipal);
  } catch (error) {
    console.error("Erro ao excluir a patrono:", error);
  }
}

/**
 * Busca uma patrono específica para atualização, com base no ID.
 * Após encontrar a patrono, renderiza o formulário de atualização.
 * @param {string} id - ID da patrono a ser buscada.
 */
async function buscarpatrono(id) {
  try {
    const response = await fetch(`${API_BASE_URL}/patrono/${id}`);
    const patronoBD = await response.json();
    if (patronoBD.length <= 0) return;

    const patrono = patronoBD.map(row => ({
      id: row.id,
      nome_pat: row.nome_pat,
      desc_pat: row.desc_pat,
      nome_especie: row.nome_especie,
    }))[0];

    const componentePrincipal = document.querySelector("#conteudo_principal");
    componentePrincipal.innerHTML = patronoView.renderizarFormularioAtualizar(patrono);
    document.getElementById("formulario_patrono_atualizar").addEventListener("submit", atualizarpatrono);
  } catch (error) {
    console.error("Erro ao buscar patrono:", error);
  }
}

/**
 * Atualiza uma patrono específica.
 * A função é acionada pelo evento de submit do formulário de atualização.
 * @param {Event} event - O evento de submit do formulário.
 */
async function atualizarpatrono(event) {
  event.preventDefault();

  const id = document.getElementById("patrono_id_formulario").value;
 /* const nome_pat = document.getElementById("patrono_nome_pat_formulario").value;
  const desc_pat = document.getElementById("patrono_desc_pat_formulario").value;
  const nome_especie = document.getElementById("patrono_nome_especie_formulario").value;*/

  const nome_pat = document.getElementById("patrono_nome_pat_formulario").value;
  const desc_pat = document.getElementById("patrono_desc_pat_formulario").value;
  const nome_especie = document.getElementById("patrono_nome_especie_formulario").value;

  const patrono = {id: id, nome_pat: nome_pat,desc_pat: desc_pat, nome_especie: nome_especie,};

  try {
    const response = await fetch(`${API_BASE_URL}/patrono`, {
      method: "PUT",
      headers: {"Content-Type": "application/json",},
      body: JSON.stringify(patrono),
    });

    if (!response.ok) {
      throw new Error("Falha ao atualizar a patrono");
    }
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListapatrono(componentePrincipal);
  } catch (error) {
    console.error("Erro ao atualizar patrono:", error);
  }
}

const patronoController = {
  renderizarpatronoFormulario,
  cadastrarpatrono,
  renderizarListapatrono,
  excluirpatrono,
};

export default patronoController;
