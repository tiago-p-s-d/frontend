/**
 * Renderiza o formulário para criar uma nova aluno.
 * @return {string} HTML do formulário de criação de aluno.
 */




///INSERT INTO tbaluno (nome_aluno, nome_casa, nome_patrono) VALUES ('clara vitoria', 'lufa lufa', 'ovelha fofa');
function renderizarFormulario() {
  return `
          <form class="mt-3" id="formulario_aluno">
              <div class="form-group">
                  <label for="aluno_titulo">Nome do aluno:</label>
                  <input type="text" class="form-control" id="aluno_nome_aluno_formulario">
              </div>
              
              <div class="form-group">
              <label for="aluno_titulo">Nome da casa:</label>
              <input type="text" class="form-control" id="aluno_nome_casa_formulario">


              <div class="form-group">
              <label for="aluno_titulo">Nome do patrono:</label>
              <input type="text" class="form-control" id="aluno_nome_patrono_formulario">
          </div>


          </div>






              <button type="submit" class="btn btn-primary mt-2">Salvar</button>
          </form>
      `;
}

/**
 * Renderiza o formulário para atualizar uma aluno existente.
 * @param {Object} aluno - A aluno a ser atualizada.
 * @return {string} HTML do formulário de atualização de aluno.
 */
function renderizarFormularioAtualizar(aluno) {
    return `
            <form class="mt-3" id="formulario_aluno_atualizar">
                <input type="hidden" class="form-control" id="aluno_id_formulario" value="${aluno.id}">

                <div class="form-group">
                    <label for="aluno_titulo">nome do aluno teste pra ver se é aqui:</label>
                    <input type="text" class="form-control" id="aluno_nome_formulario" value="${aluno.nome_aluno}">
                </div>
                <div class="form-group">
                    <label for="aluno_descricao">nome da casa:</label>
                    <textarea class="form-control" id="aluno_casa_formulario">${aluno.nome_casa}</textarea>
                </div>
                <div class="form-group">
                    <label for="aluno_descricao">nome do patrono:</label>
                    <textarea class="form-control" id="aluno_patrono_formulario">${aluno.nome_patrono}</textarea>
                </div>
                <button type="submit" class="btn btn-primary mt-2">Salvar</button>
            </form>
        `;
}

  /**
 * Renderiza a tabela de alunos.
 * @param {Array} aluno - Lista de alunos a serem exibidas.
 * @return {string} HTML da tabela de alunos.
 */
function renderizarTabela(aluno) {
  let tabela = `
          <table class="table table-striped mt-3">
              <thead>
                  <tr>
                      <th>id do aluno</th>
                      <th>nome do aluno</th>
                      <th>nome da casa</th>
                      <th>nome do patrono</th>
                  </tr>
              </thead>
              <tbody>
      `;

  aluno.forEach((aluno) => {
    tabela += `
              <tr>
                  <td>${aluno.id}</td>
                  <td>${aluno.nome_aluno}</td>
                  <td>${aluno.nome_casa}</td>
                  <td>${aluno.nome_patrono}</td>
                  <td>
                    <button class="excluir-btn" aluno-id=${aluno.id}>Excluir</button>
                    <button class="atualizar-btn" aluno-atualizar-id=${aluno.id}>Atualizar</button>
                  </td>
              </tr>
          `;
  });

  tabela += `
              </tbody>
          </table>
      `;

  return tabela;
}

const alunoView = {
    renderizarFormulario,
    renderizarTabela,
    renderizarFormularioAtualizar
};

export default alunoView;
