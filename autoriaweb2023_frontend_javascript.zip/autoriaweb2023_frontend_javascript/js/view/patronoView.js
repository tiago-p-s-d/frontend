/**
 * Renderiza o formulário para criar uma nova patrono.
 * @return {string} HTML do formulário de criação de patrono.
 */
function renderizarFormulario() {
  return `
          <form class="mt-3" id="formulario_patrono">
              <div class="form-group">
                  <label for="patrono_titulo">Nome do patrono:</label>
                  <input type="text" class="form-control" id="patrono_nome_pat_formulario">
              </div>


              <div class="form-group">
                  <label for="patrono_titulo">Descrição do patrono:</label>
                  <input type="text" class="form-control" id="patrono_desc_pat_formulario">
              </div>


              <div class="form-group">
                  <label for="patrono_titulo">Nome da especie:</label>
                  <input type="text" class="form-control" id="patrono_nome_especie_formulario">
              </div>


              <button type="submit" class="btn btn-primary mt-2">Salvar</button>
          </form>
      `;
}

/**
 * Renderiza o formulário para atualizar uma patrono existente.
 * @param {Object} patrono - A patrono a ser atualizada.
 * @return {string} HTML do formulário de atualização de patrono.
 */
function renderizarFormularioAtualizar(patrono) {
    return `
            <form class="mt-3" id="formulario_patrono_atualizar">
                <input type="hidden" class="form-control" id="patrono_id_formulario" value="${patrono.id}">
               
               
                <div class="form-group">
                    <label for="patrono_titulo">Nome do patrono:</label>
                    <input type="text" class="form-control" id="patrono_nome_pat_formulario" value="${patrono.nome_pat}">
                </div>
               
                <div class="form-group">
                    <label for="patrono_titulo">Descrição do patrono:</label>
                    <input type="text" class="form-control" id="patrono_desc_pat_formulario" value="${patrono.desc_pat}">
                </div>
                
                <div class="form-group">
                    <label for="patrono_titulo">Nome da especie:</label>
                    <input type="text" class="form-control" id="patrono_nome_especie_formulario" value="${patrono.nome_especie}">
                </div>


                <button type="submit" class="btn btn-primary mt-2">Salvar</button>
            </form>
        `;
}

  /**
 * Renderiza a tabela de patronos.
 * @param {Array} patronos - Lista de patronos a serem exibidas.
 * @return {string} HTML da tabela de patronos.
 */
function renderizarTabela(patronos) {
  let tabela = `
          <table class="table table-striped mt-3">
              <thead>
                  <tr>
                      <th>Nome do patrono</th>
                      <th>Descrição</th>
                      <th>Espécie</th>
                      <th>Ações</th>
                  </tr>
              </thead>
              <tbody>
      `;

  patronos.forEach((patrono) => {
    tabela += `
              <tr>
                  <td>${patrono.nome_pat}</td>
                  <td>${patrono.desc_pat}</td>
                  <td>${patrono.nome_especie}</td>
                  <td>
                    <button class="excluir-btn" patrono-id=${patrono.id}>Excluir</button>
                    <button class="atualizar-btn" patrono-atualizar-id=${patrono.id}>Atualizar</button>
                  </td>
              </tr>
          `;
  });

  tabela += `
              </tbody>
          </table>
      `;

  return tabela;
}

const patronoView = {
    renderizarFormulario,
    renderizarTabela,
    renderizarFormularioAtualizar
};

export default patronoView;
